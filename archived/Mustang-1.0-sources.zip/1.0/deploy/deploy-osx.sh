export VERSION="1.0"

rm -rf ../dist/*.app ../dist/*.dmg
cp setup.py ../sources

cd ../sources
python3 setup.py bdist_mac --iconfile ../resources/icon.icns
rm setup.py
mkdir -p ../dist
cp ../deploy/qt.conf build/Mustang-$VERSION.app/Contents/Resources

hdiutil create -volname Mustang-$VERSION -srcfolder build/Mustang-$VERSION.app -ov -format UDZO Mustang-$VERSION.dmg

mv Mustang-$VERSION.dmg ../dist

# cd build
# tar -zcf ../../dist/Mustang-$VERSION-OSX.tar.gz Mustang-$VERSION.app
rm -rf build