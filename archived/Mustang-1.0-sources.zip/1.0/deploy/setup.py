import sys
from cx_Freeze import setup, Executable

# Dependencies are automatically detected, but it might need fine tuning.
build_exe_options = {"packages": [], "excludes": ["tkinter"]}

# GUI applications require a different base on Windows (the default is for a
# console application).

exes = Executable("app.py", base=None)

if sys.platform == "win32":
    exes = Executable("app.py", base="Win32GUI", icon="..\\resources\\icon.ico")

setup(
    name="Mustang",
    version="1.0",
    description="Mustang",
    options={"build_exe": build_exe_options},
    executables=[exes]
)
