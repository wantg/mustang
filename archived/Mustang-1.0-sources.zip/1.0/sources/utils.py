import time
import threading
import inspect


def logging(*msgs):
    if len(msgs) == 0:
        msgs = ''
    elif len(msgs) == 1:
        msgs = msgs[0]
    print('[%s] [%s] [%s] %s' % (time.strftime('%Y-%m-%d %H:%M:%S'), inspect.currentframe().f_back.f_lineno, threading.currentThread().name, msgs))
