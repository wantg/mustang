import sys
import os
import time
import re
import socket
import threading
import utils

BUFFER_SIZE = 4096
DELAY = 0.005


class ProxyServer(threading.Thread):

    def __init__(self, host, port, whenSendDataHandler, whenRecvDataHandler, loadLocalBinHandler, showLogHandler):
        super(ProxyServer, self).__init__()
        self.host = host
        self.port = port
        self.whenSendDataHandler = whenSendDataHandler
        self.whenRecvDataHandler = whenRecvDataHandler
        self.loadLocalBinHandler = loadLocalBinHandler
        self.showLogHandler = showLogHandler

    def run(self):
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server.bind((self.host, self.port))
        self.server.listen(200)
        while 1:
            time.sleep(DELAY)
            clientSocket = self.server.accept()[0]
            reqData = clientSocket.recv(BUFFER_SIZE)
            # utils.logging('---------------- client request ----------------%s%s' % (os.linesep, str(reqData, 'utf-8')))
            # ForwardThreading(clientSocket, reqData, self.whenSendDataHandler, self.whenRecvDataHandler).start()
            threading.Thread(target=self.forward, args=(clientSocket, reqData)).start()

    def forward(self, clientSocket, reqData):
        try:
            reqs = str(reqData, 'utf-8').split('\n')[0].strip().split(' ')
            method = reqs[0].strip()
            reqUrl = reqs[1].strip()

            self.whenSendDataHandler(reqUrl)

            host = reqUrl
            port = 80

            idx = host.find('://')
            if idx > -1:
                host = host[idx + 3:]
            idx = host.find('/')
            if idx > -1:
                host = host[:idx]
            if host.find(':') > -1:
                host, port = host.split(':')
            port = int(port)

            forward = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            forward.connect((host, port))
            # forward.settimeout(5)
            if method == 'CONNECT':
                clientSocket.send(b'HTTP/1.1 200 Connection established\r\n\r\n')
                t1 = threading.Thread(target=self.t1, args=(forward, clientSocket))
                t2 = threading.Thread(target=self.t2, args=(forward, clientSocket))
                t1.start()
                t2.start()
                t1.join()
                t2.join()
                return
            forward.send(reqData)
            # utils.logging('send => --------------------------------%s%s' % (os.linesep, reqData))

            localBin = self.loadLocalBinHandler(reqUrl)
            localBinInfo = None
            if localBin is not None:
                lines = [line for line in reqData.split(b'\r\n') if line.find(b'Range: bytes=') > -1]
                if len(lines) > 0:
                    localBinInfo = {
                        'binPath': localBin,
                        'startPos': int(str(lines[0], 'utf-8').split('=')[1].split('-')[0].strip())
                    }

            while 1:
                recvData = forward.recv(BUFFER_SIZE)
                self.whenRecvDataHandler(reqUrl, recvData)
                # utils.logging('-------------------------------- recv <=%s%s' % (os.linesep, recvData))

                if localBinInfo is not None:
                    self.showLogHandler('---- read local file ---- %s' % (reqUrl))
                    self.showLogHandler('---- read local file ---- %s' % (localBinInfo['binPath']))
                    utils.logging('---- read local file ---- %s' % (reqUrl))
                    utils.logging('---- read local file ---- %s' % (localBinInfo['binPath']))
                    idx = recvData.rfind(b'\r\n\r\n')
                    firstHalfData = recvData[:idx] + b'\r\n\r\n'
                    clientSocket.send(firstHalfData)
                    with open(localBinInfo['binPath'], "rb") as f:
                        data = f.read(localBinInfo['startPos'])
                        while data:
                            data = f.read(BUFFER_SIZE * 4)
                            clientSocket.send(data)
                    break
                else:
                    lines = [line for line in recvData.split(b'\r\n') if line.find(b'Content-Length:') > -1]
                    totalLength = int(str(lines[0], 'utf-8').split(':')[1].strip()) if len(lines) > 0 else None
                    receivedLength = 0

                    # utils.logging('%s---------------- recv ----------------%s%s' % (os.linesep, os.linesep, recvData))
                    clientSocket.send(recvData)
                    receivedLength = receivedLength + len(recvData)
                    if len(recvData) == 0:
                        break
                    if totalLength is not None:
                        if receivedLength >= totalLength:
                            break
                    elif recvData[-4:] == b'\r\n\r\n':
                        break

        except Exception as e:
            self.showLogHandler(e, e.__traceback__.tb_lineno, reqs)
            utils.logging(e, e.__traceback__.tb_lineno, reqs)
            pass
        finally:
            try:
                forward.close()
            except Exception:
                # utils.logging(e, e.__traceback__.tb_lineno, reqs)
                pass
            clientSocket.close()

    def t1(self, forwardSocket, clientSocket):
        try:
            while 1:
                req = clientSocket.recv(BUFFER_SIZE)
                if len(req) == 0:
                    break
                forwardSocket.send(req)
                time.sleep(DELAY)
        except Exception as e:
            self.showLogHandler(e, e.__traceback__.tb_lineno)
            utils.logging(e, e.__traceback__.tb_lineno)
            pass

    def t2(self, forwardSocket, clientSocket):
        try:
            while 1:
                resp = forwardSocket.recv(BUFFER_SIZE)
                if len(resp) == 0:
                    break
                clientSocket.send(resp)
                time.sleep(DELAY)
        except Exception as e:
            self.showLogHandler(e, e.__traceback__.tb_lineno)
            utils.logging(e, e.__traceback__.tb_lineno)
            pass

    def stop(self):
        self.server.close()


if __name__ == '__main__':
    def whenSendData(obj):
        pass

    def whenRecvData(obj, p2):
        pass

    def loadLocalBin(obj):
        pass

    def showLogHandler(obj, p2):
        pass

    try:
        server = ProxyServer('', 8084, whenSendData, whenRecvData, loadLocalBin, showLogHandler)
        server.start()
    except Exception as e:
        print(e)
        sys.exit(1)
    except KeyboardInterrupt:
        print("Ctrl C - Stopping server")
        sys.exit(1)
