from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QStandardItemModel, QFont, QKeySequence, QCursor, QPalette, QColor, QTextCursor
from PyQt5.QtWidgets import (QApplication, QGridLayout, QGroupBox, QHBoxLayout,
                             QLabel, QLineEdit, QPushButton, QAbstractItemView, QTextEdit,
                             QVBoxLayout, QWidget, QMainWindow, QMenu, QAction, QFileDialog,
                             QTreeView, QItemDelegate, QSpinBox, QSpacerItem, QTableWidget, QTableWidgetItem)
import os
import threading
import inspect
import re
import time
import socket
import utils
from urlTable import UrlTable
from proxyServer import ProxyServer


class MainWindow(QMainWindow):

    def __init__(self):
        super(MainWindow, self).__init__()

        self.columnTitles = ('Time', 'URL', 'Size', 'Local File')
        self.setWindowTitle('Mustang')
        self.setMinimumSize(1200, 720)

        mainLayout = QVBoxLayout()
        mainLayout.addWidget(self.createProxyConfigGroup(), stretch=0)
        mainLayout.addWidget(self.createUrlInfoGroup(), stretch=1)
        mainLayout.addWidget(self.createLogGroup(), stretch=0)

        mainWidget = QWidget()
        self.setCentralWidget(mainWidget)
        mainWidget.setLayout(mainLayout)

        '''
        for i in range(1, 11):
            self.urlInfoTable.appendUrl('%d %s' % (i, time.strftime('%Y-%m-%d %H:%M:%S')))
        '''
        self.startProxyServer()

    def createProxyConfigGroup(self):
        self.proxyAddrLabel = QLabel('Address:')
        self.proxyAddrLineEdit = QLineEdit(socket.gethostbyname(socket.gethostname()))
        self.proxyPortLabel = QLabel('Port:')
        self.proxyPortSpinBox = QSpinBox()
        self.proxyPortSpinBox.setFixedWidth(60)
        self.proxyPortSpinBox.setRange(2000, 9999)
        self.proxyPortSpinBox.setSingleStep(1)
        self.proxyPortSpinBox.setValue(8084)
        self.startProxyButton = QPushButton('Start')
        self.startProxyButton.clicked.connect(self.startProxyServer)
        self.stopProxyButton = QPushButton('Stop')
        self.stopProxyButton.setDisabled(True)
        self.stopProxyButton.clicked.connect(self.stopProxyServer)
        self.exitButton = QPushButton('Exit')
        self.exitButton.clicked.connect(self.close)

        layout = QHBoxLayout()
        layout.addWidget(self.proxyAddrLabel)
        layout.addWidget(self.proxyAddrLineEdit)
        layout.addWidget(self.proxyPortLabel)
        layout.addWidget(self.proxyPortSpinBox)
        layout.addWidget(self.startProxyButton)
        layout.addWidget(self.stopProxyButton)
        layout.addWidget(self.exitButton)

        proxyConfigGroup = QGroupBox('Proxy Server')
        proxyConfigGroup.setLayout(layout)
        return proxyConfigGroup

    def createUrlInfoGroup(self):
        self.keywordLabel = QLabel('Keyword:')
        self.keywordLineEdit = QLineEdit('.pup, .pkg, /download/')
        self.clearUrlInfoButton = QPushButton('clear')
        self.clearUrlInfoButton.clicked.connect(self.clearUrlInfo)

        self.urlInfoTable = UrlTable(0, len(self.columnTitles))
        self.urlInfoTable.setHorizontalHeaderLabels(self.columnTitles)
        self.urlInfoTable.verticalHeader().setVisible(False)
        self.urlInfoTable.horizontalHeader().setStretchLastSection(True)
        self.urlInfoTable.horizontalHeaderItem(2).setTextAlignment(Qt.AlignRight)
        self.urlInfoTable.setVerticalScrollMode(QTreeView.ScrollPerPixel)
        self.urlInfoTable.setEditTriggers(QAbstractItemView.DoubleClicked | QAbstractItemView.SelectedClicked)
        font = QFont()
        font.setPixelSize(11)
        self.urlInfoTable.setFont(font)
        self.urlInfoTable.setColumnWidth(0, 60)
        self.urlInfoTable.setColumnWidth(1, 600)
        self.urlInfoTable.setColumnWidth(2, 90)
        self.urlInfoTable.show()

        hLayout = QHBoxLayout()
        hLayout.addWidget(self.keywordLabel)
        hLayout.addWidget(self.keywordLineEdit)
        hLayout.addSpacerItem(QSpacerItem(60, 0))
        hLayout.addWidget(self.clearUrlInfoButton, 0, Qt.AlignRight)

        layout = QGridLayout()
        layout.addLayout(hLayout, 0, 0)
        layout.addWidget(self.urlInfoTable)

        gridGroupBox = QGroupBox('URL List')
        gridGroupBox.setLayout(layout)
        return gridGroupBox

    def createLogGroup(self):
        self.logEditor = QTextEdit()
        self.logEditor.setMaximumHeight(140)
        self.logEditor.setReadOnly(True)
        font = QFont()
        font.setPixelSize(12)
        self.logEditor.setFont(font)
        self.logEditor.setLineWrapMode(QTextEdit.NoWrap)
        layout = QHBoxLayout()
        layout.addWidget(self.logEditor)
        logGroup = QGroupBox("Log")
        logGroup.setLayout(layout)
        return logGroup

    def whenSendData(self, reqUrl):
        self.showLog(reqUrl)
        keywords = self.keywordLineEdit.text().strip()
        matched = False
        if len(keywords) == 0:
            matched = True
        else:
            keywords = keywords.split(',')
            for keyword in keywords:
                k = keyword.strip()
                if len(k) == 0:
                    continue
                if len(re.findall(k.lower(), reqUrl.lower())) > 0:
                    matched = True
                    break
        if matched:
            urlExist = False
            for columns in self.urlInfoTable.rows():
                _s = columns[1].text().strip()
                if _s.find(reqUrl) > -1 or reqUrl.find(_s) > -1:
                    urlExist = True
                    break
            if not urlExist:
                self.urlInfoTable.appendUrl(reqUrl)

    def whenRecvData(self, reqUrl, recvData):
        if len(recvData) == 0:
            return
        lines = [line for line in recvData.split(b'\r\n') if line.find(b'Content-Length:') > -1]
        totalLength = int(str(lines[0], 'utf-8').split(':')[1].strip()) if len(lines) > 0 else len(recvData)
        for columns in self.urlInfoTable.rows():
            _s = columns[1].text().strip()
            if _s.find(reqUrl) > -1 or reqUrl.find(_s) > -1:
                size = 0
                try:
                    _t = columns[2].text().strip()
                    if len(_t) > 0:
                        size = int(_t)
                except Exception as e:
                    utils.logging(e)
                    self.showLog(e)
                    pass
                size = max(size, totalLength)
                columns[2].setText(str(size))
                break

    def loadLocalBin(self, reqUrl):
        localBin = None

        for columns in self.urlInfoTable.rows():
            _s = columns[1].text().strip()
            if _s.find(reqUrl) > -1 or reqUrl.find(_s) > -1:
                localBinPath = columns[3].text().strip()
                if os.path.exists(localBinPath):
                    localBin = localBinPath
                    break

        return localBin

    def showLog(self, *logs):
        if len(logs) == 0:
            logs = ''
        elif len(logs) == 1:
            logs = logs[0]
        logs = '[%s] [%03d] [%s] %s' % (time.strftime('%H:%M:%S'), inspect.currentframe().f_back.f_lineno, threading.currentThread().name, logs)
        self.logEditor.append(logs)
        self.logEditor.verticalScrollBar().setValue(self.logEditor.verticalScrollBar().maximum())

    def disableWidget(self, disabled):
        self.proxyAddrLabel.setDisabled(disabled)
        self.proxyAddrLineEdit.setDisabled(disabled)
        self.proxyPortLabel.setDisabled(disabled)
        self.proxyPortSpinBox.setDisabled(disabled)
        self.startProxyButton.setDisabled(disabled)
        self.stopProxyButton.setDisabled(not disabled)
        self.keywordLabel.setDisabled(disabled)
        self.keywordLineEdit.setDisabled(disabled)

    def startProxyServer(self):
        self.disableWidget(True)
        self.proxyServer = ProxyServer(self.proxyAddrLineEdit.text(), int(self.proxyPortSpinBox.text()), self.whenSendData, self.whenRecvData, self.loadLocalBin, self.showLog)
        self.proxyServer.start()

    def stopProxyServer(self):
        self.disableWidget(False)
        try:
            self.proxyServer.stop()
        except Exception:
            pass

    def clearUrlInfo(self):
        self.urlInfoTable.removeAllRows()

    def closeEvent(self, event):
        self.stopProxyServer()


if __name__ == '__main__':

    import sys
    try:
        app = QApplication(sys.argv)
        mainWin = MainWindow()
        mainWin.show()
        sys.exit(app.exec_())
    except KeyboardInterrupt:
        print('Ctrl C - Stopping server')
        sys.exit(1)
