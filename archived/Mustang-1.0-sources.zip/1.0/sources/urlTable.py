from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QStandardItemModel, QFont, QKeySequence, QCursor, QPalette, QColor
from PyQt5.QtWidgets import (QApplication, QGridLayout, QGroupBox, QHBoxLayout,
                             QLabel, QLineEdit, QPushButton, QAbstractItemView,
                             QVBoxLayout, QWidget, QMainWindow, QMenu, QAction, QFileDialog,
                             QTreeView, QItemDelegate, QSpinBox, QSpacerItem, QTableWidget, QTableWidgetItem)
import os
import re
import time
import socket
import utils


class UrlTable(QTableWidget):

    def __init__(self, rowCount, columnCount):
        super(QTableWidget, self).__init__(rowCount, columnCount)
        self.selectedItemText = None
        self.setAcceptDrops(True)
        '''
        for f in dir(self):
            break
            print(f, getattr(self, f).__class__)
        '''
        self.itemSelectionChanged.connect(self.itemEnteredEvent)
        self.itemChanged.connect(self.itemChangedEvent)
        # self.customContextMenuRequested.connect(self.urlInfoContextMenuEvent)

    def itemEnteredEvent(self):
        self.selectedItemText = self.item(self.currentRow(), self.currentColumn()).text()

    def itemChangedEvent(self, currentItem):
        if self.selectedItemText is None:
            return
        if currentItem.column() == 1:
            currentItem.setText(self.selectedItemText)
        elif currentItem.column() == 3:
            if not os.path.isfile(currentItem.text().strip()):
                pass
                # currentItem.setText(self.selectedItemText)

    def dragEnterEvent(self, event):
        event.acceptProposedAction()

    def dragMoveEvent(self, event):
        event.acceptProposedAction()
        self.selectRow(self.indexAt(event.pos()).row())

    def dragLeaveEvent(self, event):
        event.accept()
        self.selectRow(-1)

    def dropEvent(self, event):
        event.acceptProposedAction()
        mimeData = event.mimeData()
        modelIndex = self.indexAt(event.pos()).row()
        if modelIndex > -1:
            fileUrl = mimeData.urls()[0]
            # print(fileUrl)
            filePath = fileUrl.toLocalFile()
            if not os.path.exists(filePath):
                filePath = fileUrl.path()
            self.item(modelIndex, 3).setText(filePath)
            self.selectRow(modelIndex)

    def rows(self):
        rows = []
        for rowIdx in range(0, self.rowCount()):
            columns = []
            for columnIdx in range(0, self.columnCount()):
                columns.append(self.item(rowIdx, columnIdx))
            rows.append(columns)
        return rows

    def appendUrl(self, url):
        idx = self.rowCount()
        self.insertRow(idx)
        item1 = QTableWidgetItem(time.strftime('%H:%M:%S'))
        item1.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
        item2 = QTableWidgetItem(url)
        item3 = QTableWidgetItem('')
        item3.setTextAlignment(Qt.AlignRight | Qt.AlignCenter)
        item3.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
        item4 = QTableWidgetItem('')
        self.setItem(idx, 0, item1)
        self.setItem(idx, 1, item2)
        self.setItem(idx, 2, item3)
        self.setItem(idx, 3, item4)

    def removeAllRows(self):
        while self.rowCount() > 0:
            self.removeRow(0)
